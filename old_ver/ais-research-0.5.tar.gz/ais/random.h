#ifndef __MY_RANDOM_H__
#define __MY_RANDOM_H__

int randomInt(int);
float randomCoin();

#endif

/* itoa.h
 */

#ifndef _ITOA_H_
#define _ITOA_H_

#pragma once

#include <stdio.h>
#include <stdlib.h>

char * itoa (int);

#endif

/* itoa.h */

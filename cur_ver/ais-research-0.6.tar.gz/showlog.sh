#!/bin/sh

while [ 1 ]
do
clear
echo
echo "=======================   Traffic Log   ======================="
echo
echo
cat traffic.log
sleep 2
done

